int parserEmployee(File* pFile , ArrayList* pArrayListEmployee);
